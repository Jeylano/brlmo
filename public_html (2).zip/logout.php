<?php
// Mulai sesi
session_start();

// Mengaktifkan pengaturan aman untuk sesi
ini_set('session.cookie_secure', 1);  // Hanya mengirimkan cookie melalui HTTPS
ini_set('session.cookie_httponly', 1);  // Mencegah akses cookie melalui JavaScript

// Regenerasi ID sesi untuk mencegah session fixation
if (!isset($_SESSION['user_id'])) {
    session_regenerate_id(true);  // Regenerasi ID sesi baru
}
?>
