<?php
// Menghindari caching halaman sensitif
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

// Menghindari penggunaan frame untuk mencegah Clickjacking
header('X-Frame-Options: DENY');

// Menambahkan Content Security Policy (CSP)
header("Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none';");

// Mencegah MIME Sniffing
header('X-Content-Type-Options: nosniff');

// Mengaktifkan HTTP Strict Transport Security (HSTS)
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
?>
