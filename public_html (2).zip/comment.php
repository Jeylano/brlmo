<?php
// Ambil input pengguna
$user_input = $_POST['comment'];  // Misalnya, input dari komentar pengguna

// Sanitasi input untuk menghindari XSS
$safe_input = htmlspecialchars($user_input, ENT_QUOTES, 'UTF-8');

// Menampilkan input yang sudah aman
echo "Komentar Anda: " . $safe_input;
?>
