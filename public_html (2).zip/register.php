<?php
// Koneksi ke database
$pdo = new PDO('mysql:host=localhost;dbname=your_db_name', 'root', 'password');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Ambil data dari form
$username = $_POST['username'];
$password = $_POST['password'];

// Query yang aman dengan prepared statement
$stmt = $pdo->prepare('SELECT * FROM users WHERE username = :username AND password = :password');
$stmt->bindParam(':username', $username);
$stmt->bindParam(':password', $password);
$stmt->execute();
?>
