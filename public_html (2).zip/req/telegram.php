<?php
$id_telegram = "7069546529";
$id_botTele  = "7861347147:AAE82DicIpe-vQNgYJBk-K3Vvh05suuK_n8";
$exp = "2024-07-14"; //atur tanggal expired website (Tahun, Bulan, Tanggal)
$nowa = "6285220618249";
?>
